@echo off
cd /d "%~dp0"
echo.
echo   cpp-ai-agent v0.2.0
echo.
echo   用法:
echo     ai-agent.exe              # 终端 TUI 模式
echo     ai-agent.exe /web 8080   # 浏览�?Web 模式
echo     ai-agent.exe /doctor     # 诊断配置
echo     ai-agent.exe /demo       # 演示模式
echo     ai-agent.exe /skills     # 查看 Skill
echo.
echo   先编�?.env 填入你的 API Key 再启动！
echo.
cmd /k
